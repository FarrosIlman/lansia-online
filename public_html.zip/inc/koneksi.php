<?php
$koneksi = new mysqli ("localhost","id19110042_root","Silansia123!","id19110042_db_lansia");
?>